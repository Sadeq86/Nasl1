module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {
    const voiceChannelId = '1328645767564492800';
    const client = newState.client;
    
    // If the bot itself was in the VC and moved or disconnected
    if (oldState.member.id === client.user.id && oldState.channelId === voiceChannelId && newState.channelId !== voiceChannelId) {
      const channel = client.channels.cache.get(voiceChannelId);
      if (channel) {
        try {
          const { joinVoiceChannel } = require('@discordjs/voice');
          joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
          });
          console.log(`Bot re-joined 24/7 VC after disconnection/move`);
        } catch (e) {
          console.error(`Failed to re-join 24/7 VC:`, e);
        }
      }
    }
  }
};
