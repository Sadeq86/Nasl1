const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('result')
    .setDescription(
      'Send a custom message through the bot to a specified channel'
    )
    .setDefaultMemberPermissions(0) // No default permissions — we manually check the role
    .addChannelOption(
      (option) =>
        option
          .setName('channel')
          .setDescription('The channel where the message will be sent')
          .setRequired(true)
          .addChannelTypes(0) // Text channels only
    )
    .addStringOption((option) =>
      option
        .setName('message')
        .setDescription('The content of the message')
        .setRequired(true)
        .setMaxLength(2000)
    )
    .addBooleanOption((option) =>
      option
        .setName('embed')
        .setDescription('Send the message as an embed? (default: no)')
        .setRequired(false)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const channel = interaction.options.getChannel('channel');
    const messageText = interaction.options.getString('message');
    const asEmbed = interaction.options.getBoolean('embed') ?? false;

    // === REPLACE WITH YOUR DESIRED ROLE ID ===
    const allowedRoleId = '1411083330773848194'; // ← Put your role ID here

    // Check if the user has the required role
    if (!interaction.member.roles.cache.has(allowedRoleId)) {
      return interaction.editReply({
        content:
          '❌ You do not have permission to use this command. Only members with the specified role can use `/result`.',
      });
    }

    // Check bot permissions in the target channel
    const botPermissions = channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions?.has(['ViewChannel', 'SendMessages'])) {
      return interaction.editReply({
        content: `❌ I lack the required permissions to send messages in ${channel}.`,
      });
    }

    if (asEmbed && !botPermissions.has('EmbedLinks')) {
      return interaction.editReply({
        content:
          '❌ I need the **Embed Links** permission to send embeds in that channel.',
      });
    }

    try {
      if (asEmbed) {
        const embed = {
          color: 0x5865f2, // Discord blurple
          description: messageText,
          timestamp: new Date(),
          footer: {
            text: `Sent by ${interaction.user.tag}`,
            icon_url: interaction.user.displayAvatarURL({ dynamic: true }),
          },
        };

        await channel.send({ embeds: [embed] });
      } else {
        await channel.send(messageText);
      }

      await interaction.editReply({
        content: `✅ Message successfully sent to ${channel}!`,
      });
    } catch (error) {
      console.error('Error executing /result command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while trying to send the message.',
      });
    }
  },
};
